app.asar v2.3.2 for Win 2020.2 fix

1. Replace c:\Program Files\Unity Hub\resources\app.asar to patched file
2. Launch Hub as admin
3. On Installs page click three dots on the needed version and select "Patch Pro" from menu
4. Wait a minute (35 seconds in my case).
5. If you don't have patched license file also click on "Patch License"



Unity Hub 2.3.2 for OSX patched

0. Close Hub
1. Replace /Applications/Unity Hub.app/Contents/Resources/app.asar to patched file
2. Launch Hub
3. If Hub starts with errors, del ~Library/Application Support/UnityHub folder content except *.json files. Close and Run Hub again.
4. On Installs page click three dots on the needed version and select "Patch Pro" from menu
5. If you don't have patched license file also click on "Patch License"